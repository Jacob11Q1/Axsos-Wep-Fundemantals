let count = 3;
function changeLikes(){
    count++;
    document.querySelector("#like-counts").innerText = count + " Like(s)";
}