let count = 9;
function changeLikes(){
    count++;
    document.querySelector("#likes").innerText = count + " Like(s)";
}

let counts = 12;
function likesone(){
    counts++;
    document.querySelector("#likes-1").innerText = counts + " Like(s)";
}

let changecount = 9;
function likeschange(){
    changecount++;
    document.querySelector("#likes-2").innerText = changecount + " Like(s)";
}