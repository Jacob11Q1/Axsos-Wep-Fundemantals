function custom(){
    console.log('Ninja Was Liked');
}
function turnOff(element){
    element.innerText = 'LogOut';
}
function hide(element){
    element.remove();
}